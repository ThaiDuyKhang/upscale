import { Router } from 'express';
import { stmt, completeDeposit } from '../db.js';
import { verifySePayAuth, extractPaymentCode } from '../payments/sepay.js';
import { verifyPay2sSignature, extractPay2sTransaction } from '../payments/pay2s.js';

export const webhookRouter = Router();

// ---------------- SePay ----------------
// SePay yêu cầu endpoint trả về HTTP 200 trong vòng 30 giây, nếu không sẽ retry
// tối đa 7 lần trong ~33 phút. Vì vậy route này xử lý nhanh, không gọi thêm API
// chậm nào khác.
webhookRouter.post('/sepay', (req, res) => {
  if (!verifySePayAuth(req)) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }
  const payload = req.body;

  // Chỉ quan tâm giao dịch tiền VÀO
  if (payload.transferType !== 'in') {
    return res.json({ success: true, ignored: true });
  }

  const pendingDeposits = stmt.findAllPendingDeposits.all();
  const candidateCodes = pendingDeposits.map(d => d.code).filter(Boolean);
  const matchedCode = extractPaymentCode(payload, candidateCodes);

  if (!matchedCode) {
    // Không khớp được giao dịch nào đang chờ — vẫn trả 200 để SePay không retry,
    // nhưng KHÔNG cộng credit cho ai cả. Bạn nên có chỗ xem lại các giao dịch
    // "không khớp" này trong admin để đối soát thủ công nếu cần.
    console.warn('[sepay-webhook] Không khớp được mã giao dịch nào:', payload.content);
    return res.json({ success: true, matched: false });
  }

  const tx = stmt.findTxByCode.get(matchedCode);
  if (!tx || tx.status !== 'pending') {
    return res.json({ success: true, matched: false, reason: 'Giao dịch đã xử lý trước đó hoặc không tồn tại.' });
  }

  if (payload.transferAmount < tx.amount_vnd) {
    console.warn(`[sepay-webhook] Số tiền chuyển (${payload.transferAmount}) nhỏ hơn số tiền cần (${tx.amount_vnd}) cho mã ${matchedCode}`);
    return res.json({ success: true, matched: false, reason: 'Số tiền không khớp.' });
  }

  completeDeposit(tx, payload);
  console.log(`[sepay-webhook] Đã cộng ${tx.credits_delta} credit cho user ${tx.user_id} (mã ${matchedCode})`);
  res.json({ success: true, matched: true });
});

// ---------------- Pay2S ----------------
// XEM GHI CHÚ trong src/payments/pay2s.js trước khi bật route này lên production —
// tên field trong body dưới đây là suy đoán hợp lý, chưa được xác nhận 100% với
// tài liệu mới nhất của Pay2S.
webhookRouter.post('/pay2s', (req, res) => {
  if (!verifyPay2sSignature(req.body)) {
    return res.status(401).json({ success: false, error: 'Chữ ký không hợp lệ.' });
  }
  const { orderCode, amount } = extractPay2sTransaction(req.body);
  if (!orderCode) return res.json({ success: true, matched: false });

  const tx = stmt.findTxByCode.get(orderCode);
  if (!tx || tx.status !== 'pending') {
    return res.json({ success: true, matched: false });
  }
  if (amount < tx.amount_vnd) {
    return res.json({ success: true, matched: false, reason: 'Số tiền không khớp.' });
  }

  completeDeposit(tx, req.body);
  res.json({ success: true, matched: true });
});
