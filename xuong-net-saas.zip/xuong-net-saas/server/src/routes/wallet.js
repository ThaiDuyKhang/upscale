import { Router } from 'express';
import { nanoid } from 'nanoid';
import { stmt, creditUser, getSetting } from '../db.js';
import { requireAuth } from '../auth.js';
import { buildVietQrImageUrl } from '../payments/vietqr.js';

export const walletRouter = Router();
walletRouter.use(requireAuth);

// Sinh mã nội dung chuyển khoản duy nhất. Tiền tố "NAP" giúp bạn cấu hình
// "Cấu trúc mã thanh toán" trong SePay Dashboard để SePay tự nhận diện field "code".
function generateDepositCode() {
  return 'NAP' + nanoid(8).toUpperCase();
}

walletRouter.get('/', (req, res) => {
  const user = stmt.findUserById.get(req.user.sub);
  res.json({ credits: user.credits });
});

walletRouter.get('/transactions', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  const pageSize = 20;
  const rows = stmt.listTxForUser.all(req.user.sub, pageSize, (page - 1) * pageSize);
  res.json({ items: rows, page, pageSize });
});

walletRouter.post('/deposits', (req, res) => {
  const amountVnd = parseInt(req.body?.amountVnd, 10);
  const minDeposit = parseInt(getSetting('min_deposit_vnd') || '10000', 10);
  const vndPerCredit = parseInt(getSetting('vnd_per_credit') || '1000', 10);

  if (!amountVnd || amountVnd < minDeposit) {
    return res.status(400).json({ error: `Số tiền nạp tối thiểu là ${minDeposit.toLocaleString('vi-VN')}đ.` });
  }

  const credits = Math.floor(amountVnd / vndPerCredit);
  const code = generateDepositCode();

  const txId = creditUser({
    userId: req.user.sub,
    delta: credits,
    type: 'deposit',
    status: 'pending',
    amountVnd,
    code,
    provider: 'sepay', // đổi thành 'pay2s' nếu bạn dùng Pay2S làm cổng chính
  });

  const qrImageUrl = buildVietQrImageUrl({ amountVnd, content: code });

  res.json({
    transactionId: txId,
    code,
    amountVnd,
    credits,
    qrImageUrl,
    bank: {
      accountNumber: process.env.BANK_ACCOUNT_NUMBER,
      accountName: process.env.BANK_ACCOUNT_NAME,
    },
    instructions: `Chuyển khoản đúng số tiền ${amountVnd.toLocaleString('vi-VN')}đ, nội dung ghi đúng mã: ${code}`,
  });
});

// Frontend gọi định kỳ để biết deposit đã được xác nhận qua webhook hay chưa.
walletRouter.get('/deposits/:id', (req, res) => {
  const tx = stmt.findTxById.get(req.params.id);
  if (!tx || tx.user_id !== req.user.sub) return res.status(404).json({ error: 'Không tìm thấy giao dịch.' });
  res.json({ status: tx.status, credits: tx.credits_delta, amountVnd: tx.amount_vnd, code: tx.code });
});
